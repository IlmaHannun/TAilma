import 'package:get/get.dart';

class DashboardController extends GetxController {
  get tabIndex => null;

  get changeTabIndex => null;
  
}
