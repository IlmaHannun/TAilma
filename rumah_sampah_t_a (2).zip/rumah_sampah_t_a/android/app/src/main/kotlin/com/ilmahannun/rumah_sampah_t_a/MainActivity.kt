package com.ilmahannun.rumah_sampah_t_a

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
